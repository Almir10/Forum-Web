package WebInfo_248.ForumWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForumWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
