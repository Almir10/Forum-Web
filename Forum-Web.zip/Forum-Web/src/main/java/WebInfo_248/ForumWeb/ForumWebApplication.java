package WebInfo_248.ForumWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForumWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForumWebApplication.class, args);
	}

}
