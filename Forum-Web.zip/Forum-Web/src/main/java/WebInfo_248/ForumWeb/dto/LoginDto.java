package WebInfo_248.ForumWeb.dto;

import lombok.Data;

@Data
public class LoginDto {

    private String email;
    private String password;

}
