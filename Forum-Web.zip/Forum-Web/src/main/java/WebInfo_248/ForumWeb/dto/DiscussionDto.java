package WebInfo_248.ForumWeb.dto;

public class DiscussionDto {
}
