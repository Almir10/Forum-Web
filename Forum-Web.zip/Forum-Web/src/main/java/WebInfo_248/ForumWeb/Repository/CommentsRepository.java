package WebInfo_248.ForumWeb.Repository;

import WebInfo_248.ForumWeb.Models.Comments;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommentsRepository extends JpaRepository<Comments, Integer> {

}
